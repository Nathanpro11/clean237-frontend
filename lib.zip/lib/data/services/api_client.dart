import 'dart:convert';

import 'package:dio/dio.dart';

import '../exceptions/app_exception.dart';
import '../../utils/constances/api_constants.dart';

class ApiClient {
  ApiClient({Dio? dio})
      : _dio = dio ??
            Dio(
              BaseOptions(
                baseUrl: ApiConstants.baseUrl,
                connectTimeout: ApiConstants.connectTimeout,
                receiveTimeout: ApiConstants.receiveTimeout,
                headers: {
                  'Content-Type': 'application/json',
                  'Accept': 'application/json',
                },
              ),
            );

  final Dio _dio;

  Future<Response<T>> get<T>(
    String path, {
    Map<String, dynamic>? queryParameters,
  }) async {
    return _request(
      _dio.get<T>(path, queryParameters: queryParameters),
    );
  }

  Future<Response<T>> post<T>(
    String path, {
    Object? data,
    Map<String, dynamic>? queryParameters,
  }) async {
    return _request(
      _dio.post<T>(path, data: data, queryParameters: queryParameters),
    );
  }

  Future<Response<T>> delete<T>(
    String path, {
    Object? data,
    Map<String, dynamic>? queryParameters,
  }) async {
    return _request(
      _dio.delete<T>(path, data: data, queryParameters: queryParameters),
    );
  }

  Future<Response<T>> patch<T>(
    String path, {
    Object? data,
    Map<String, dynamic>? queryParameters,
  }) async {
    return _request(
      _dio.patch<T>(path, data: data, queryParameters: queryParameters),
    );
  }

  Future<Response<List<int>>> getBytes(
    String path, {
    Map<String, dynamic>? queryParameters,
  }) async {
    return _request(
      _dio.get<List<int>>(
        path,
        queryParameters: queryParameters,
        options: Options(responseType: ResponseType.bytes),
      ),
    );
  }

  Future<Response<T>> _request<T>(Future<Response<T>> request) async {
    try {
      return await request;
    } on DioException catch (error) {
      throw _mapError(error);
    }
  }

  AppException _mapError(DioException error) {
    final statusCode = error.response?.statusCode;
    final backendMessage = _extractMessage(error.response?.data);
    switch (statusCode) {
      case 400:
        return ValidationException(backendMessage, statusCode: 400);
      case 404:
        return NotFoundException(backendMessage);
      case 409:
        return ConflictException(backendMessage);
      case 422:
        return ValidationException(backendMessage, statusCode: 422);
      case 500:
      case 501:
      case 502:
      case 503:
      case 504:
        return ServerException(backendMessage);
      default:
        if (statusCode != null && statusCode >= 400 && statusCode < 500) {
          return ValidationException(
            backendMessage,
            statusCode: statusCode,
          );
        }
        if (statusCode != null && statusCode >= 500) {
          return ServerException(backendMessage, statusCode: statusCode);
        }
        return NetworkException(error.message ?? 'Erreur réseau');
    }
  }

  String _extractMessage(dynamic payload) {
    if (payload is List<int>) {
      try {
        payload = jsonDecode(utf8.decode(payload));
      } on FormatException {
        return 'Une erreur est survenue.';
      }
    }
    if (payload is String) {
      try {
        payload = jsonDecode(payload);
      } on FormatException {
        return payload.isNotEmpty ? payload : 'Une erreur est survenue.';
      }
    }
    if (payload is Map) {
      final map = Map<String, dynamic>.from(payload);
      final message = map['message'];
      if (message is String && message.trim().isNotEmpty) {
        return message;
      }
      final error = map['error'];
      if (error is String && error.trim().isNotEmpty) {
        return error;
      }
    }
    return 'Une erreur est survenue.';
  }
}
